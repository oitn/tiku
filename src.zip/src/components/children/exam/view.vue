<template>
	<div class='exam-view'>
		<router-view></router-view>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.exam-view{
		height: 100%;
	}
</style>
