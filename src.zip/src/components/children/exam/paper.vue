<template>
	<div class='paper'>
		<tk-question 
			type='checkbox' 
			ifShowStar='false' 
			index='1'
			question='HelloWorld'
			onChoose='' 
			:disable='false' 
			:option='["hello", "a", "bcd"]'
		>
		</tk-question>
		<div class='footer'>
			<div>上一题</div>
			<div>下一题</div>
		</div>
	</div>
</template>

<script>
	import Question from '../../plug/tiku-question.vue'
	export default {
		components:{
			'tk-question': Question
		},
		data() {
			return {
				
			};
		}
	}
</script>

<style lang='scss'>
	.paper{
		/* height: calc(100vh - 3.5rem); */
		box-sizing: border-box;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		align-items: center;
		.footer{
		}
	}
</style>
