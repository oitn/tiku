export default {
	isLogin: true,
	currentPage: '题库'
}
